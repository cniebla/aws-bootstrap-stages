# aws-bootstrap
From the book "The Good Parts of AWS"
